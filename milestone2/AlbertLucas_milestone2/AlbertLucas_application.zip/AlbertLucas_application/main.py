import sys
import psycopg2
from PyQt6.QtWidgets import QMainWindow, QApplication, QWidget, QTableWidget, QTableWidgetItem, QVBoxLayout
from PyQt6 import uic, QtCore, QtGui

qtCreatorFile = "milestone2App.ui"  # Enter file here.

Ui_MainWindow, QtBaseClass = uic.loadUiType(qtCreatorFile)


class milestone2(QMainWindow):
    def __init__(self):
        super(milestone2, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.loadStateList()
        self.ui.stateList.currentTextChanged.connect(self.stateChanged)
        self.ui.cityList.itemSelectionChanged.connect(self.cityChanged)
        self.ui.postalCodeList.itemSelectionChanged.connect(self.postalcodeChanged)
        self.ui.businessSearchButton.clicked.connect(self.searchBusiness)

    def executeQuery(self, sql_str):
        try:
            conn = psycopg2.connect("dbname='milestone2db' user='postgres' host='localhost' password='BAB0Y!'")
        except:
            print('Unable to connect to the database')
        cur = conn.cursor()
        cur.execute(sql_str)
        conn.commit()
        result = cur.fetchall()
        conn.close()
        return result

    def loadStateList(self):
        self.ui.stateList.clear()
        sql_str = "SELECT distinct state FROM  business ORDER BY state;"
        try:
            results = self.executeQuery(sql_str)
            # print(results)
            for row in results:
                self.ui.stateList.addItem(row[0])
        except:
            print("Query failed")
        self.ui.stateList.setCurrentIndex(-1)
        self.ui.stateList.clearEditText()

    def stateChanged(self):
        self.ui.cityList.clear()
        self.ui.postalCodeList.clear()
        state = self.ui.stateList.currentText()
        if(self.ui.stateList.currentIndex() >= 0):
            sql_str = "SELECT distinct city FROM business WHERE state ='" + state + "' ORDER BY city;"
            try:
                results = self.executeQuery(sql_str)
                for row in results:
                    self.ui.cityList.addItem(row[0])
                print(results)
            except:
                print("Query failed")

            # for i in reversed(range(self.ui.businessTable.rowCount())):
            #     self.ui.businessTable.removeRow(i)
            # sql_str = "SELECT name, city, state FROM business WHERE state = '" + state + "' ORDER BY name;"
            # try:
            #     results = self.executeQuery(sql_str)
            #     style = "::section {""background-color: #f3f3f3; }"
            #     self.ui.businessTable.horizontalHeader().setStyleSheet(style)
            #     self.ui.businessTable.setColumnCount(len(results[0]))
            #     self.ui.businessTable.setRowCount(len(results))
            #     self.ui.businessTable.setHorizontalHeaderLabels(['Business Name', 'City', 'State'])
            #     self.ui.businessTable.resizeColumnsToContents()
            #     self.ui.businessTable.setColumnWidth(0, 300)
            #     self.ui.businessTable.setColumnWidth(1, 100)
            #     self.ui.businessTable.setColumnWidth(2, 50)
            #     currentRowCount = 0
            #     for row in results:
            #         for colCount in range(0, len(results[0])):
            #             self.ui.businessTable.setItem(currentRowCount, colCount, QTableWidgetItem(row[colCount]))
            #         currentRowCount += 1
            # except:
            #     print("query failed")
    def cityChanged(self):
        if(self.ui.stateList.currentIndex() >= 0) and (len(self.ui.cityList.selectedItems()) > 0):
            state = self.ui.stateList.currentText()
            city = self.ui.cityList.selectedItems()[0].text()
            sql_str = "SELECT distinct postal_code FROM business WHERE state ='" + state + "' AND city='" + city + "' ORDER BY postal_code;"
            # print(sql_str)
            results = self.executeQuery(sql_str)
            try:
                self.ui.postalCodeList.clear()
                self.ui.categoryList.clear()
                for row in results:
                    self.ui.postalCodeList.addItem(row[0])
            except:
                print("Query failed")
            # try:
            #     results = self.executeQuery(sql_str)
            #     style = "::section {""background-color: #f3f3f3; }"
            #     self.ui.businessTable.horizontalHeader().setStyleSheet(style)
            #     self.ui.businessTable.setColumnCount(len(results[0]))
            #     self.ui.businessTable.setRowCount(len(results))
            #     self.ui.businessTable.setHorizontalHeaderLabels(['Business Name', 'City', 'State'])
            #     self.ui.businessTable.resizeColumnsToContents()
            #     self.ui.businessTable.setColumnWidth(0, 300)
            #     self.ui.businessTable.setColumnWidth(1, 100)
            #     self.ui.businessTable.setColumnWidth(2, 50)
            #     currentRowCount = 0
            #     for row in results:
            #         for colCount in range(0, len(results[0])):
            #             self.ui.businessTable.setItem(currentRowCount, colCount, QTableWidgetItem(row[colCount]))
            #         currentRowCount += 1
            # except:
            #     print("query failed")

    def postalcodeChanged(self):
        # adds category list
        if(self.ui.stateList.currentIndex() >= 0) and (len(self.ui.cityList.selectedItems()) > 0) and (len(self.ui.postalCodeList.selectedItems()) > 0):
            state = self.ui.stateList.currentText()
            city = self.ui.cityList.selectedItems()[0].text()
            postalCode = self.ui.postalCodeList.selectedItems()[0].text()
            sql_str = "SELECT DISTINCT category " + \
                      "FROM business_category " + \
                      "JOIN business ON business.business_id = business_category.business_id " + \
                      "WHERE state = '" + state + "' " + \
                      "AND city = '" + city + "' " + \
                      "AND postal_code = '" + postalCode + "' " + \
                      "ORDER BY category;"
            try:
                self.ui.categoryList.clear()
                results = self.executeQuery(sql_str)
                for row in results:
                    self.ui.categoryList.addItem(row[0])
            except:
                print("Query failed")
    def searchBusiness(self):
        if (
                self.ui.stateList.currentIndex() >= 0
                and len(self.ui.cityList.selectedItems()) > 0
                and len(self.ui.postalCodeList.selectedItems()) > 0
                and len(self.ui.categoryList.selectedItems()) > 0
        ):
            state = self.ui.stateList.currentText()
            city = self.ui.cityList.selectedItems()[0].text()
            postalCode = self.ui.postalCodeList.selectedItems()[0].text()
            category = self.ui.categoryList.selectedItems()[0].text()
            try:
                sql_str = "SELECT name, address, city, stars, review_count, review_rating, num_checkins FROM business WHERE state = '" + state + "' AND city = '" + city + "' AND postal_code = '" + postalCode + "' AND business_id IN (SELECT business_id FROM business_category WHERE category = '" + category + "') ORDER BY name;"
                results = self.executeQuery(sql_str)
                style = "::section {""background-color: #f3f3f3; }"
                self.ui.businessTable.horizontalHeader().setStyleSheet(style)
                self.ui.businessTable.setRowCount(len(results))
                self.ui.businessTable.setHorizontalHeaderLabels(
                    ['Business Name', 'Address', 'City', 'Stars', 'Review Count', 'Review Rating',
                     'Number of Checkins'])
                if results:  # Check if results is not empty
                    self.ui.businessTable.setColumnCount(len(results[0]))
                    self.ui.businessTable.resizeColumnsToContents()
                    self.ui.businessTable.setColumnWidth(0, 150)
                    self.ui.businessTable.setColumnWidth(1, 150)
                    self.ui.businessTable.setColumnWidth(2, 100)
                    self.ui.businessTable.setColumnWidth(3, 50)
                    self.ui.businessTable.setColumnWidth(4, 50)
                    self.ui.businessTable.setColumnWidth(5, 50)
                    self.ui.businessTable.setColumnWidth(6, 50)
                    currentRowCount = 0
                    for row in results:
                        for colCount in range(0, len(results[0])):
                            self.ui.businessTable.setItem(currentRowCount, colCount, QTableWidgetItem(row[colCount]))
                        currentRowCount += 1
                else:
                    print("No results found")
            except:
                print("Query failed")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = milestone2()
    window.show()
    sys.exit(app.exec())
